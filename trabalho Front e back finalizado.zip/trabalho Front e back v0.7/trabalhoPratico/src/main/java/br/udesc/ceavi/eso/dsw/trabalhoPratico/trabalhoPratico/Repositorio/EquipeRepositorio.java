/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Repositorio;

import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Equipe;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.IntegranteEquipe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author Gabriel Soares
 */
public interface EquipeRepositorio extends JpaRepository<Equipe, Long>, CrudRepository<Equipe, Long> {

    @Query(value = "SELECT ie.* FROM integrante_equipe ie WHERE ie.id=:id", nativeQuery = true)
    IntegranteEquipe buscarIntegranteCadastrado(@Param("id") long id);
    
    @Query(value = "SELECT e FROM Equipe e WHERE e.id=:id", nativeQuery = true)
    IntegranteEquipe buscarEquipe(@Param("id") long id);
    
    
}
