/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Repositorio;

import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Arena;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Equipe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author Gabriel Soares
 */
public interface ArenaRepositorio extends JpaRepository<Arena, Long>{

    @Query(value = "SELECT e.* FROM equipe e WHERE e.id =:id", nativeQuery = true)
    Object[] buscarEquipe(@Param("id") long id);
}
