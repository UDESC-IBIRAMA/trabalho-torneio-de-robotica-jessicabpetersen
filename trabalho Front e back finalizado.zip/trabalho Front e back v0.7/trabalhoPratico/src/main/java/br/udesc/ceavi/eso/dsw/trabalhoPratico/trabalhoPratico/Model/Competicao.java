/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Gabriel Soares
 */
@Entity
public class Competicao implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_competicao")
    private List<Arena> listaArenas = new ArrayList();
    private String cidade;
    
    @Temporal(TemporalType.DATE)
    private Date data;
    private String responsavel;
    private String tipoCompeticao;
    
    private String uf;

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }
    
    
    @OneToOne(cascade=CascadeType.PERSIST)
    @JoinColumn(name="id_temporada") 
    private Temporada temporada;

    public String getCidade() {
        return cidade;
    }

    public void adicionarArena(Arena arena){
        this.listaArenas.add(arena);
    }
    
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(String responsavel) {
        this.responsavel = responsavel;
    }

    public String getTipoCompeticao() {
        return tipoCompeticao;
    }

    public void setTipoCompeticao(String tipoCompeticao) {
        this.tipoCompeticao = tipoCompeticao;
    }

    public Temporada getTemporada() {
        return temporada;
    }

    public void setTemporada(Temporada temporada) {
        this.temporada = temporada;
    }
    
    public List<Arena> getListaArenas() {
        return listaArenas;
    }

    public void setListaArenas(List<Arena> listaArenas) {
        this.listaArenas = listaArenas;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Competicao)) {
            return false;
        }
        Competicao other = (Competicao) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Competicao[ id=" + id + " ]";
    }

}
