/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Controller;

import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Categoria;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Competicao;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Sala_Avaliacao;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Repositorio.CategoriaRepositorio;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Repositorio.CompeticaoRepositorio;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Repositorio.SalaRepositorio;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author 42519630833
 */
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/salas")
public class SalaAvaliacaoController {

    @Autowired
    SalaRepositorio sr;

    @GetMapping("/{id}")
    public Sala_Avaliacao buscar(@PathVariable long id) {
        return sr.findById(id).get();
    }

    @GetMapping
    public List<Sala_Avaliacao> buscar() {
        return sr.findAll();
    }

    @Autowired
    CompeticaoRepositorio cr;
    
    @Autowired
    CategoriaRepositorio catr;
    
    @PostMapping("/{idCompeticao}/cat/{idCategoria}")
    public Sala_Avaliacao salvar(@PathVariable long idCompeticao, @PathVariable long idCategoria, @RequestBody Sala_Avaliacao sala) {
        
        Competicao comp = cr.findById(idCompeticao).get();
        Categoria cat = catr.findById(idCategoria).get();
        sala.setCompeticao(comp);
        sala.setCategoria(cat);
        
        return sr.save(sala);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable long id) {
        sr.deleteById(id);
    }

    @PutMapping("/{id}")
    public Sala_Avaliacao atualizar(@PathVariable long id, @RequestBody Sala_Avaliacao sala) {

        Optional<Sala_Avaliacao> arenaSalvo = sr.findById(id);
        Sala_Avaliacao as = arenaSalvo.get();//Transforma optional na entidade
        sr.save(as);

        return as;
    }
}
