/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Repositorio;

import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Temporada;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author Gabriel Soares
 */
public interface TemporadaRepositorio extends JpaRepository<Temporada, Long>{
    
}
