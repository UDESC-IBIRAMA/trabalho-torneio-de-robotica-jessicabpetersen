/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

/**
 *
 * @author Gabriel Soares
 */
@Entity
public class Equipe_Sala implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @OneToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "id_equipe1")
    private Equipe equipe1;

    @OneToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "id_equipe2")
    private Equipe equipe2;

    @OneToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "id_salaAvaliacao")
    private Sala_Avaliacao salaAvaliacao;

    @OneToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "id_alternativa")
    private Alternativa alternativa;

    public Alternativa getAlternativa() {
        return alternativa;
    }

    public void setAlternativa(Alternativa alternativa) {
        this.alternativa = alternativa;
    }
    

    public Equipe getEquipe1() {
        return equipe1;
    }

    public void setEquipe1(Equipe equipe1) {
        this.equipe1 = equipe1;
    }

    public Equipe getEquipe2() {
        return equipe2;
    }

    public void setEquipe2(Equipe equipe2) {
        this.equipe2 = equipe2;
    }

    public Sala_Avaliacao getSalaAvaliacao() {
        return salaAvaliacao;
    }

    public void setSalaAvaliacao(Sala_Avaliacao salaAvaliacao) {
        this.salaAvaliacao = salaAvaliacao;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Equipe_Sala)) {
            return false;
        }
        Equipe_Sala other = (Equipe_Sala) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Equipe_Sala[ id=" + id + " ]";
    }

}
