/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Controller;

import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Arena;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Competicao;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Equipe;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Model.Rodada;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Repositorio.ArenaRepositorio;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Repositorio.CompeticaoRepositorio;
import br.udesc.ceavi.eso.dsw.trabalhoPratico.trabalhoPratico.Repositorio.EquipeRepositorio;
import java.math.BigInteger;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Gabriel Soares
 */
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/arenas")
public class ArenaControlle {

    @Autowired
    private ArenaRepositorio ar;

    @GetMapping("/{id}")
    public Arena buscar(@PathVariable long id) {
        return ar.findById(id).get();
    }

    @GetMapping
    public List<Arena> buscar() {
        return ar.findAll();
    }

    @Autowired
    CompeticaoRepositorio cr;
    
    @PostMapping("/{idCompeticao}")
    public Competicao salvar(@PathVariable long idCompeticao, @RequestBody Arena arena) {
        Competicao comp = cr.findById(idCompeticao).get();
        comp.adicionarArena(arena);
        return cr.save(comp);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable long id) {
        ar.deleteById(id);
    }

    @PutMapping
    public Arena atualizar(@RequestBody Arena arena) {

        ar.save(arena);

        return arena;
    }
    
    @Autowired
    private EquipeRepositorio er;
    
    @PutMapping("/arena/{id}/equipe/{idEquipe}")
    public Arena adicionarEquipe(@PathVariable long id, @PathVariable long idEquipe) {
        Equipe eq = er.findById(idEquipe).get();
        
        Arena arenaSalvo = ar.findById(id).get();  
        arenaSalvo.getListaEquipes().add(eq);
        
        ar.save(arenaSalvo);
        
        return arenaSalvo;
    }
    
    @PutMapping("/arenaNota/{id}")
    public Arena adicionarRodada(@PathVariable long id, @RequestBody Rodada rodada) {
  
        Arena arenaSalvo = ar.findById(id).get();  
        arenaSalvo.getListaRodadas().add(rodada);
        
        ar.save(arenaSalvo);
        
        return arenaSalvo;
    }
}
