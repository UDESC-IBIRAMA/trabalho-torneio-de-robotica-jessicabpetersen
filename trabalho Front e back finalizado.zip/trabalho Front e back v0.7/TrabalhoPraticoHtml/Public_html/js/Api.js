/* global EQUIPES_PATH, pEQUIPES_PATH, fetch, CAMPEONATO_PATH, CATEGORIA_PATH, JUIZES_PATH, TEMPORADA_PATH, arrayIntegrantes, CRITERIO_PATH, JUIZ_PATH, SALA_PATH, ARENA_PATH */
this.campeonato = [];
var categoria = [];
this.equipes = [];
this.temporadas = [];
arrayIntegrantes = [];

class APIxpto {
    constructor() {
    }

    _onGetCampeonatos() {
        var myHeaders = new Headers();

        var myInitGet = {method: 'GET',
            headers: myHeaders,
            mode: 'cors',
            cache: 'default'};

        fetch(CAMPEONATO_PATH, myInitGet)
                .then(dataWrappedByPromise => dataWrappedByPromise.json())
                .then(data => {
                    //console.log(data);
                    this.campeonato = data;
                });
    }

    _renderCampeonato() {
        console.log(this.campeonato);
        const selectCompeticao = document.querySelector('#selectCompeticao');
        var count = 0;
        for (const c of this.campeonato) {

            selectCompeticao[count] = c.cidade;
            count = count + 1;
        }

        this.campeonato = null;
    }
}
function getCampeonatos() {

    var myHeaders = new Headers();

    var myInitGet = {
        method: 'GET',
        headers: myHeaders,
        mode: 'cors',
        cache: 'default'};

    fetch(CAMPEONATO_PATH, myInitGet)
            .then(dataWrappedByPromise => dataWrappedByPromise.json())
            .then(data => {
                this.campeonato = data;
                renderizaCompeticao();
            });

}

function renderizaCompeticao() {
    const selectCompeticao = document.querySelector('#selectCompeticao');
    var count = 0;
    for (const c of this.campeonato) {
        selectCompeticao.options[count] = new Option(c.cidade, c.id);
        count = count + 1;
    }

    this.campeonato = null;
}


function getEquipes() {

    var myHeaders = new Headers();

    var myInitGet = {
        method: 'GET',
        headers: myHeaders,
        mode: 'cors',
        cache: 'default'};

    fetch(EQUIPES_PATH, myInitGet)
            .then(dataWrappedByPromise => dataWrappedByPromise.json())
            .then(data => {
                this.equipes = data;
                renderizaEquipes();
            });

}

function renderizaEquipes() {
    const selectEquipes = document.querySelector('#selectEquipes');
    var count = 0;
    for (const e of this.equipes) {
        selectEquipes.options[count] = new Option(e.nome, e.id);
        count = count + 1;
    }

    this.equipes = null;
}

function getTemporadas() {

    var myHeaders = new Headers();

    var myInitGet = {
        method: 'GET',
        headers: myHeaders,
        mode: 'cors',
        cache: 'default'};

    fetch(TEMPORADA_PATH, myInitGet)
            .then(dataWrappedByPromise => dataWrappedByPromise.json())
            .then(data => {
                this.temporadas = data;
                renderizaTemporada();
            });

}

function renderizaTemporada() {
    const selectTemporada = document.querySelector('#selectTemporadas');
    var count = 0;
    for (const c of this.temporadas) {
        selectTemporada.options[count] = new Option(c.nome, c.id);
        count = count + 1;
    }

    this.temporadas = null;
}

this.objetoEquipeJson;

function cadastrarEquipe() {

    var sNomeEquipe = document.getElementById('nomeEquipe').value;

    let objetoEquipe = Object();
    objetoEquipe.nome = sNomeEquipe;


    fetch(EQUIPES_PATH, {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify(objetoEquipe)

    });

}

this.objetoJuizJson;

function cadastrarJuiz() {

    var sNome = document.getElementById('nomeJuiz').value;
    var sCpf = document.getElementById('cpfJuiz').value;
    var dData_nascimento = document.getElementById('dataNascimento').value;

    var objJuiz = new Object();

    objJuiz.nome = sNome;
    objJuiz.cpf = sCpf;
    objJuiz.data_nascimento = dData_nascimento;



    fetch(JUIZ_PATH, {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify(objJuiz)

    });

}

this.objetoTemporadaJson;

function cadastrarTemporada() {
    debugger;

    var sNome = document.getElementById('inputNomeTemporada').value;
    var sDescricao = document.getElementById('textAreaTemporada').value;
    objetoTemporadaJson = '{' +
            '"nome":"' + sNome + '",' +
            '"descricao":"' + sDescricao +
            '"}';

    fetch(TEMPORADA_PATH, {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        method: "POST",
        body: objetoTemporadaJson

    });
}


function adicionarIntegrante() {
    
    debugger;
    var sNomeIntegrante = document.getElementById('inputNome[]').value;
    var sRgIntegrante = document.getElementById('inputRg[]').value;
    var sCpfIntegrante = document.getElementById('inputcpf').value;
    var sDataNascimento = document.getElementById('inputData[]').value;
    var nomeMae = document.getElementById('inputNomeMae[]').value;
    var nomePai = document.getElementById('inputNomePai[]').value;
    var equipe = document.getElementById('selectEquipes').value;
    var obrigatorio = document.getElementById('inputDocumentos[]').value;

    if(obrigatorio === "on"){
        obrigatorio = true;
    }else{
        obrigatorio = false;
    }
    var objIntegrante = new Object();

    objIntegrante.nome = sNomeIntegrante;
    objIntegrante.rg = sRgIntegrante;
    objIntegrante.cpf = sCpfIntegrante;
    objIntegrante.data_nascimento = sDataNascimento;
    objIntegrante.nomeMae = nomeMae;
    objIntegrante.nomePai = nomePai;
    objIntegrante.validacao_documentos = obrigatorio;

    fetch(EQUIPES_PATH + "/" + equipe, {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        method: "PUT",
        body: JSON.stringify(objIntegrante)

    });
}

function cadastrarCampeonato() {
    debugger;
    var sCidade = document.getElementById('inputCidade').value;
    var sUF = document.getElementById('cEst').value;
    var dData = document.getElementById('inputData').value;
    var sResponsavel = document.getElementById('inputResponsavel').value;
    var sTipo = document.getElementById('selectTipo').value;
    var temporada = document.getElementById('selectTemporadas').value;


    var objCompeticao = new Object();
    objCompeticao.cidade = sCidade;
    objCompeticao.data = dData;
    objCompeticao.responsavel = sResponsavel;
    objCompeticao.tipoCompeticao = sTipo;
    objCompeticao.uf = sUF;

    fetch(CAMPEONATO_PATH + temporada, {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify(objCompeticao)

    });
}

function cadastroCategoriaEMissoes() {

    var sNomeCategoria = document.getElementById('nomeCategoria').value;
    var sDescricaoCategoria = document.getElementById('descricaoCategoria').value;
    var sNomeCriterio = document.getElementById('nomeCriterio').value;
    var sDescricaoCriterio = document.getElementById('descricaoCriterio').value;

    var juizesDaCategoria = [8, 9];
    var listaDeJuizes = [];


    for (var i = 0; i < juizesDaCategoria.length; i++) {

        var myHeaders = new Headers();
        var myInitGet = {
            method: 'GET',
            headers: myHeaders,
            mode: 'cors',
            cache: 'default'};


        fetch(JUIZ_PATH + "/" + juizesDaCategoria[i], myInitGet)
                .then(dataWrappedByPromise => dataWrappedByPromise.json())
                .then(data => {
                    listaDeJuizes.push(data);
                });

    }
    var objCategoria = new Object();

    objCategoria.nome = sNomeCategoria;
    objCategoria.descricao = sDescricaoCategoria;
    objCategoria.juizesDaCategoria = listaDeJuizes;


    var objCriterio = new Object();

    objCriterio.nome = sNomeCriterio;
    objCriterio.descricao = sDescricaoCriterio;
    objCriterio.categoria = objCategoria;

    fetch(CRITERIO_PATH, {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify(objCriterio)

    });
}
function cadastrarAlternativa() {

    let idCriterio = document.getElementById('selectCriterio').value;

    let objAlternativa = new Object();
    objAlternativa.valor = document.getElementById('valorAlternativa').value;

    fetch(CRITERIO_PATH + "/" + idCriterio, {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        method: "PUT",
        body: JSON.stringify(objAlternativa)

    });

}

function getCategoria() {

    var myHeaders = new Headers();

    var myInitGet = {
        method: 'GET',
        headers: myHeaders,
        mode: 'cors',
        cache: 'default'};

    fetch(CATEGORIA_PATH, myInitGet)
            .then(dataWrappedByPromise => dataWrappedByPromise.json())
            .then(data => {
                this.categoria = data;
                renderizaCategoria();
            });

}

function renderizaCategoria() {
    const selectCompeticao = document.querySelector('#selectCategoria');
    var count = 0;
    for (const c of this.categoria) {
        selectCompeticao.options[count] = new Option(c.nome, c.id);
        count = count + 1;
    }

    this.categoria = null;
}

this.juizes = [];
function getjuiz() {

    var myHeaders = new Headers();

    var myInitGet = {
        method: 'GET',
        headers: myHeaders,
        mode: 'cors',
        cache: 'default'};

    fetch(JUIZ_PATH, myInitGet)
            .then(dataWrappedByPromise => dataWrappedByPromise.json())
            .then(data => {
                this.juizes = data;
                renderizaJuiz();
            });

}

function renderizaJuiz() {
    const selectCompeticao = document.querySelector('#tabelaCarregarJuizes');

    var string = "";
    for (const c of this.juizes) {
        string += "<tr><td>" + c.nome + "</td><td><input type=\"checkbox\" id=\"" + c.id + "\"></td></tr>";
    }
    selectCompeticao.innerHTML = "<table id=\"tabela\"> <thead><th>Nome</th><th>Selecionado</th></thead>" + string + "</table>";
    this.juizes = null;
}


this.criterios = [];
function getCriterios() {
    var myHeaders = new Headers();

    var myInitGet = {
        method: 'GET',
        headers: myHeaders,
        mode: 'cors',
        cache: 'default'};

    fetch(CRITERIO_PATH, myInitGet)
            .then(dataWrappedByPromise => dataWrappedByPromise.json())
            .then(data => {
                this.criterios = data;
                renderizaCriterio();
            });

}

function renderizaCriterio() {
    const selectCompeticao = document.querySelector('#selectCriterio');
    var count = 0;
    for (const c of this.criterios) {
        selectCompeticao.options[count] = new Option(c.nome, c.id);
        count = count + 1;
    }

    this.categoria = null;
}

function cadastrarSala() {
    var idCompeticao = document.getElementById('selectCompeticao').value;
    var idCategoria = document.getElementById('selectCategoria').value;
    var sNome = document.getElementById('nomeSala').value;



    var objSala = new Object();
    objSala.nome = sNome;


    fetch(SALA_PATH + "/" + idCompeticao + "/cat/" + idCategoria, {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify(objSala)

    });
}

function cadastrarArena() {
    debugger;
    var idCompeticao = document.getElementById('selectCompeticao').value;
    var sNome = document.getElementById('nomeSala').value;



    var objArena = new Object();
    objArena.nome = sNome;


    fetch(ARENA_PATH + "/" + idCompeticao, {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify(objArena)

    });
}


