/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var valorNovoCampoTorneio = 2, valorNovoCampoEquipe = 2, valorNovoCampoCriterio = 2, tamanhoAlternativa=0;

function duplicarCamposTorneio(){
	var clone = document.getElementById('formulario').cloneNode(true),
            destino = document.getElementById('destino');
  
	destino.appendChild (clone);
	var camposClonados = clone.getElementsByTagName('input');
	for(i=0; i<camposClonados.length;i++){
		camposClonados[i].value = '';
	}
        var campoComp =clone.getElementsByTagName('p')[0];
        campoComp.innerHTML = "Competição " +valorNovoCampoTorneio;
        valorNovoCampoTorneio++;
        
        
}
function removerCamposTorneio(id){
	var node1 = document.getElementById('destino');
	node1.removeChild(node1.childNodes[valorNovoCampoTorneio-3]);
        valorNovoCampoTorneio--;
}

function duplicarCamposEquipe(){
	var clone = document.getElementById('formulario').cloneNode(true),
            destino = document.getElementById('destino');
  
	destino.appendChild (clone);
	var camposClonados = clone.getElementsByTagName('input');
	for(i=0; i<camposClonados.length;i++){
		camposClonados[i].value = '';
	}
        var campoComp =clone.getElementsByTagName('p')[0];
        campoComp.innerHTML = "Integrante "+valorNovoCampoEquipe;
        valorNovoCampoEquipe++;
        
        
}
function removerCamposEquipe(id){
	var node1 = document.getElementById('destino');
	node1.removeChild(node1.childNodes[valorNovoCampoEquipe-2]);
        valorNovoCampoEquipe--;
}

function duplicarCamposCriterio(){
	var clone = document.getElementById('criterios').cloneNode(true),
            destino = document.getElementById('destino');
  
        clone.removeChild(clone.getElementsByTagName('div')[1]);
	destino.appendChild (clone);
	var camposClonados = clone.getElementsByTagName('input');
	for(i=0; i<camposClonados.length;i++){
		camposClonados[i].value = '';
	}
        var campoComp =clone.getElementsByTagName('p')[0];
        campoComp.innerHTML = "Critério "+valorNovoCampoCriterio;
        valorNovoCampoCriterio++;
        
        
}
function removerCamposCriterio(id){
	var node1 = document.getElementById('destino');
	node1.removeChild(node1.childNodes[valorNovoCampoCriterio-3]);
        valorNovoCampoCriterio--;
}

function duplicarCamposAlternativa(){
	var clone = document.getElementById('alternativa').cloneNode(true),
            destino = document.getElementById('altDest');
  
	destino.appendChild (clone);
	var camposClonados = clone.getElementsByTagName('input');
	for(i=0; i<camposClonados.length;i++){
		camposClonados[i].value = '';
	}
        var campoComp =clone.getElementsByTagName('p')[0];
        tamanhoAlternativa++;
}

function removerCamposAlternativa(id){
	var node1 = document.getElementById('altDest');
	node1.removeChild(node1.childNodes[tamanhoAlternativa-1]);
        tamanhoAlternativa--;
}