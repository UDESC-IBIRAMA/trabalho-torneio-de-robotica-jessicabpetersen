/* global EQUIPES_PATH */
/* global pEQUIPES_PATH */
/* global VEICULOS_PATH */

const EQUIPES_PATH = 'http://localhost:8080/equipes';
const CAMPEONATO_PATH = 'http://localhost:8080/competicoes/';
const CATEGORIA_PATH = 'http://localhost:8080/categorias';
const JUIZ_PATH = 'http://localhost:8080/juizes';
const TEMPORADA_PATH = 'http://localhost:8080/temporadas';
const CRITERIO_PATH = 'http://localhost:8080/criterios';
const SALA_PATH = 'http://localhost:8080/salas';
const ARENA_PATH = 'http://localhost:8080/arenas';

const api = new APIxpto();


function _onJsonReady(json) {
  console.log(json);
}

function _onResponse(response) {
  return response.json();
}

